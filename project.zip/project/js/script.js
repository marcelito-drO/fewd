// Start by adding the ability to call the function as soon as the page loads / is called by the user

document.addEventListener("DOMContentLoaded", spaceAdventure);

function spaceAdventure(event){
// Random number generated for first part of the game
  document.querySelector("#numberOf").textContent = Math.floor(Math.random() * 10) + 1;

// PokeApi used here to spit out a random Pokemon
  var pokemonID = Math.floor(Math.random() * 364) + 1;
  var urlPoke = "https://pokeapi.co/api/v2/pokemon/" + pokemonID;
    $.get(urlPoke, displayPokemon);

    function displayPokemon(results) {
      console.log("pokemon",results);
      document.querySelector("#thePokemon").textContent = results.name;
      document.querySelector(".pokemon").setAttribute("src",results.sprites.front_default);
    }

// StarWars API to call a character
  var starwarsID = Math.floor(Math.random() * 70) + 1;
  var urlStarwars = "https://swapi.co/api/people/" + starwarsID + "?format=json";
    $.get(urlStarwars, displayStarwars);

    function displayStarwars(results) {
      console.log("character",results);
      document.querySelector("#starCharacter").textContent = results.name;
    }

// StarWars API to call a planet
  var planetID = Math.floor(Math.random() * 20) + 1;
  var urlPlanet = "https://swapi.co/api/planets/" + planetID + "?format=json";
    $.get(urlPlanet, displayPlanet);

    function displayPlanet(results) {
      console.log("planet",results);
      document.querySelector("#starplanet").textContent = results.name;
    }
  }

// Input a set of actions that is randomly generated at the time that the user reloads the page or clicks on the new story button
